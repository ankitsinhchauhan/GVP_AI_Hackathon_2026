const API_URL = 'http://localhost:3000';

// DOM Elements
const addStudentForm = document.getElementById('addStudentForm');
const attendanceForm = document.getElementById('attendanceForm');
const performanceForm = document.getElementById('performanceForm');
const searchBtn = document.getElementById('searchBtn');
const loadStudentsBtn = document.getElementById('loadStudentsBtn');
const notification = document.getElementById('notification');

// Show notification
function showNotification(message, type = 'info') {
    notification.textContent = message;
    notification.className = `notification ${type} show`;
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// Handle Add Student
addStudentForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const rollNo = document.getElementById('rollNo').value;
    const name = document.getElementById('name').value;
    const semester = document.getElementById('semester').value;
    
    try {
        const response = await fetch(`${API_URL}/addStudent`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rollNo, name, semester })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Student added successfully!', 'success');
            addStudentForm.reset();
            loadStudentList();
        } else {
            showNotification(data.error || 'Error adding student', 'error');
        }
    } catch (error) {
        showNotification('Failed to connect to server', 'error');
        console.error('Error:', error);
    }
});

// Handle Attendance
attendanceForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const rollNo = document.getElementById('attendanceRollNo').value;
    const totalLectures = document.getElementById('totalLectures').value;
    const attendedLectures = document.getElementById('attendedLectures').value;
    
    if (parseInt(attendedLectures) > parseInt(totalLectures)) {
        showNotification('Attended lectures cannot exceed total lectures', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/markAttendance`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rollNo, totalLectures, attendedLectures })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Attendance updated successfully!', 'success');
            attendanceForm.reset();
            
            // Show AI warning if applicable
            if (data.warning && data.warning.includes('Warning')) {
                showNotification(data.warning, 'warning');
            }
        } else {
            showNotification(data.error || 'Error updating attendance', 'error');
        }
    } catch (error) {
        showNotification('Failed to connect to server', 'error');
        console.error('Error:', error);
    }
});

// Handle Performance
performanceForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const rollNo = document.getElementById('marksRollNo').value;
    const marks = document.getElementById('marks').value;
    
    try {
        const response = await fetch(`${API_URL}/addMarks`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rollNo, marks })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showNotification('Marks updated successfully!', 'success');
            performanceForm.reset();
            
            // Show AI remark
            if (data.performance && data.performance.remark) {
                showNotification(`Performance: ${data.performance.remark}`, 'info');
            }
        } else {
            showNotification(data.error || 'Error updating marks', 'error');
        }
    } catch (error) {
        showNotification('Failed to connect to server', 'error');
        console.error('Error:', error);
    }
});

// Search for Student Report
searchBtn.addEventListener('click', async () => {
    const rollNo = document.getElementById('searchRollNo').value;
    
    if (!rollNo) {
        showNotification('Please enter a roll number', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/studentReport/${rollNo}`);
        const data = await response.json();
        
        if (response.ok) {
            displayStudentReport(data.student);
        } else {
            showNotification(data.error || 'Student not found', 'error');
            document.getElementById('reportResult').innerHTML = 
                `<p class="placeholder">${data.error || 'Student not found'}</p>`;
        }
    } catch (error) {
        showNotification('Failed to connect to server', 'error');
        console.error('Error:', error);
    }
});

// Load All Students
loadStudentsBtn.addEventListener('click', loadStudentList);

async function loadStudentList() {
    try {
        const response = await fetch(`${API_URL}/students`);
        const data = await response.json();
        
        if (response.ok) {
            displayStudentList(data.students);
        } else {
            showNotification('Error loading students', 'error');
        }
    } catch (error) {
        showNotification('Failed to connect to server', 'error');
        console.error('Error:', error);
    }
}

// Display Student Report
function displayStudentReport(student) {
    const reportResult = document.getElementById('reportResult');
    
    // Determine attendance badge class
    let attendanceBadgeClass = 'attendance-good';
    if (student.attendance.percentage < 75) {
        attendanceBadgeClass = student.attendance.percentage < 50 ? 'attendance-danger' : 'attendance-warning';
    }
    
    // Determine performance badge class
    let performanceBadgeClass = 'performance-good';
    if (student.performance.marks < 75) {
        performanceBadgeClass = student.performance.marks < 50 ? 'performance-poor' : 'performance-average';
    }
    
    const reportHTML = `
        <div class="report-header">
            <h3>${student.name} (${student.rollNo})</h3>
            <p>Semester: ${student.semester}</p>
        </div>
        
        <div class="report-details">
            <div class="report-item">
                <span class="report-label">Total Lectures:</span>
                <span class="report-value">${student.attendance.totalLectures || 0}</span>
            </div>
            <div class="report-item">
                <span class="report-label">Attended Lectures:</span>
                <span class="report-value">${student.attendance.attendedLectures || 0}</span>
            </div>
            <div class="report-item">
                <span class="report-label">Attendance Percentage:</span>
                <span class="attendance-badge ${attendanceBadgeClass}">
                    ${student.attendance.percentage || 0}%
                </span>
            </div>
            <div class="report-item">
                <span class="report-label">Attendance Status:</span>
                <span class="report-value">
                    ${student.attendance.percentage >= 75 ? 'Satisfactory' : 
                      student.attendance.percentage >= 50 ? 'Warning' : 'Critical'}
                    ${student.attendance.percentage < 75 ? ' (Below 75%)' : ''}
                </span>
            </div>
            <div class="report-item">
                <span class="report-label">Marks Obtained:</span>
                <span class="report-value">${student.performance.marks || 0}/100</span>
            </div>
            <div class="report-item">
                <span class="report-label">Average:</span>
                <span class="report-value">${student.performance.average || 0}%</span>
            </div>
            <div class="report-item">
                <span class="report-label">Performance Remark:</span>
                <span class="performance-badge ${performanceBadgeClass}">
                    ${student.performance.remark || 'Not Available'}
                </span>
            </div>
        </div>
        
        <div class="ai-insights-report" style="margin-top: 20px; padding: 15px; background: #f0f9ff; border-radius: 10px;">
            <h4><i class="fas fa-brain"></i> AI Analysis</h4>
            <ul style="margin-top: 10px; padding-left: 20px;">
                <li>Roll Number Validated: ${/^[A-Z]{2}\d{3,}$|^\d{7,}$/.test(student.rollNo) ? '✓' : '✗'}</li>
                <li>Attendance Status: ${student.attendance.percentage >= 75 ? '✓ Above threshold' : 
                                        student.attendance.percentage >= 50 ? '⚠ Needs attention' : '✗ Critical'}</li>
                <li>Performance Level: ${student.performance.marks >= 75 ? 'Good' : 
                                       student.performance.marks >= 50 ? 'Average' : 'Needs Improvement'}</li>
            </ul>
        </div>
    `;
    
    reportResult.innerHTML = reportHTML;
}

// Display Student List
function displayStudentList(students) {
    const studentList = document.getElementById('studentList');
    
    if (!students || students.length === 0) {
        studentList.innerHTML = '<p class="placeholder">No students found</p>';
        return;
    }
    
    let studentListHTML = '';
    
    students.forEach(student => {
        // Determine attendance badge
        let attendanceBadgeClass = 'attendance-good';
        let attendanceText = 'Good';
        if (student.attendance.percentage < 75) {
            attendanceBadgeClass = student.attendance.percentage < 50 ? 'attendance-danger' : 'attendance-warning';
            attendanceText = student.attendance.percentage < 50 ? 'Critical' : 'Warning';
        }
        
        // Determine performance badge
        let performanceBadgeClass = 'performance-good';
        let performanceText = student.performance.remark || 'N/A';
        
        studentListHTML += `
            <div class="student-item">
                <div class="student-info">
                    <h4>${student.name}</h4>
                    <p>Roll No: ${student.rollNo} | Semester: ${student.semester}</p>
                </div>
                <div class="student-stats">
                    <span class="attendance-badge ${attendanceBadgeClass}" style="margin-right: 10px;">
                        ${student.attendance.percentage || 0}%
                    </span>
                    <span class="performance-badge ${performanceBadgeClass}">
                        ${student.performance.marks || 0}/100
                    </span>
                </div>
            </div>
        `;
    });
    
    studentList.innerHTML = studentListHTML;
}

// Initialize the application
function init() {
    showNotification('Welcome to AI-Assisted Smart Attendance & Performance Tracker!', 'info');
}

// Run initialization when page loads
document.addEventListener('DOMContentLoaded', init);