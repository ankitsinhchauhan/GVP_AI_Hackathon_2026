const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/attendance_tracker', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Student Schema
const studentSchema = new mongoose.Schema({
    rollNo: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    semester: { type: String, required: true },
    attendance: {
        totalLectures: { type: Number, default: 0 },
        attendedLectures: { type: Number, default: 0 },
        percentage: { type: Number, default: 0 }
    },
    performance: {
        marks: { type: Number, default: 0 },
        average: { type: Number, default: 0 },
        remark: { type: String, default: '' }
    }
});

const Student = mongoose.model('Student', studentSchema);

// AI-Assisted Validation Functions
const aiValidations = {
    // Roll number validation (AI logic: Must follow pattern like "CS001" or "2023001")
    validateRollNo: (rollNo) => {
        const pattern = /^[A-Z]{2}\d{3,}$|^\d{7,}$/;
        return pattern.test(rollNo);
    },
    
    // Attendance warning (AI logic: Calculate and warn if < 75%)
    checkAttendance: (total, attended) => {
        const percentage = (attended / total) * 100;
        return {
            percentage: percentage.toFixed(2),
            warning: percentage < 75 ? `Warning: Attendance (${percentage.toFixed(2)}%) is below 75%` : 'Attendance is satisfactory'
        };
    },
    
    // Performance remark (AI logic: Categorize based on marks)
    getPerformanceRemark: (marks) => {
        if (marks >= 75) return { remark: "Good", category: "success" };
        if (marks >= 50) return { remark: "Average", category: "warning" };
        return { remark: "Needs Improvement", category: "danger" };
    }
};

// API Endpoints

// 1. Add Student
app.post('/addStudent', async (req, res) => {
    try {
        const { rollNo, name, semester } = req.body;
        
        // AI Validation: Check roll number format
        if (!aiValidations.validateRollNo(rollNo)) {
            return res.status(400).json({ 
                error: 'Invalid roll number format. Use pattern like CS001 or 2023001' 
            });
        }
        
        // Check if student already exists
        const existingStudent = await Student.findOne({ rollNo });
        if (existingStudent) {
            return res.status(400).json({ error: 'Student with this roll number already exists' });
        }
        
        const student = new Student({ rollNo, name, semester });
        await student.save();
        
        res.status(201).json({ 
            message: 'Student added successfully', 
            student 
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 2. Mark Attendance
app.post('/markAttendance', async (req, res) => {
    try {
        const { rollNo, totalLectures, attendedLectures } = req.body;
        
        // Find student
        const student = await Student.findOne({ rollNo });
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }
        
        // AI Calculation: Attendance percentage and warning
        const attendanceData = aiValidations.checkAttendance(totalLectures, attendedLectures);
        
        // Update student attendance
        student.attendance = {
            totalLectures: parseInt(totalLectures),
            attendedLectures: parseInt(attendedLectures),
            percentage: parseFloat(attendanceData.percentage)
        };
        
        await student.save();
        
        res.json({ 
            message: 'Attendance updated successfully',
            attendance: student.attendance,
            warning: attendanceData.warning
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 3. Add Marks
app.post('/addMarks', async (req, res) => {
    try {
        const { rollNo, marks } = req.body;
        
        // Find student
        const student = await Student.findOne({ rollNo });
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }
        
        // AI Logic: Performance remark
        const performanceData = aiValidations.getPerformanceRemark(marks);
        
        // Update student performance
        student.performance = {
            marks: parseInt(marks),
            average: parseInt(marks), // For single subject, average = marks
            remark: performanceData.remark
        };
        
        await student.save();
        
        res.json({ 
            message: 'Marks updated successfully',
            performance: student.performance
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 4. Get Student Report
app.get('/studentReport/:roll', async (req, res) => {
    try {
        const { roll } = req.params;
        
        const student = await Student.findOne({ rollNo: roll });
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }
        
        res.json({ student });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 5. Get All Students
app.get('/students', async (req, res) => {
    try {
        const students = await Student.find();
        res.json({ students });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});